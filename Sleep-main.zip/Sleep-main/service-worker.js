// Sleep Optimizer - Service Worker v2.0
// Advanced PWA functionality with intelligent caching and background sync

const CACHE_NAME = 'sleep-optimizer-v2.0';
const DATA_CACHE_NAME = 'sleep-optimizer-data-v2.0';

// Assets to cache immediately on install
const STATIC_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  'https://unpkg.com/react@18/umd/react.production.min.js',
  'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js',
  'https://unpkg.com/@babel/standalone/babel.min.js'
];

// ==================== INSTALL EVENT ====================
self.addEventListener('install', (event) => {
  console.log('[ServiceWorker] Installing...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[ServiceWorker] Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('[ServiceWorker] Skip waiting');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('[ServiceWorker] Install failed:', error);
      })
  );
});

// ==================== ACTIVATE EVENT ====================
self.addEventListener('activate', (event) => {
  console.log('[ServiceWorker] Activating...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME && cacheName !== DATA_CACHE_NAME) {
              console.log('[ServiceWorker] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[ServiceWorker] Claiming clients');
        return self.clients.claim();
      })
  );
});

// ==================== FETCH EVENT ====================
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip cross-origin requests
  if (url.origin !== location.origin) {
    // But cache CDN resources
    if (url.host.includes('unpkg.com')) {
      event.respondWith(
        caches.match(request)
          .then((response) => {
            if (response) {
              return response;
            }
            
            return fetch(request).then((response) => {
              if (!response || response.status !== 200) {
                return response;
              }
              
              const responseToCache = response.clone();
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(request, responseToCache);
              });
              
              return response;
            });
          })
      );
    }
    return;
  }

  // Handle API/Data requests differently
  if (url.pathname.includes('/api/')) {
    event.respondWith(networkFirstStrategy(request));
    return;
  }

  // Handle navigation requests
  if (request.mode === 'navigate') {
    event.respondWith(
      caches.match(request)
        .then((response) => {
          return response || fetch(request).then((response) => {
            const responseToCache = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseToCache);
            });
            return response;
          });
        })
        .catch(() => {
          // Return offline page if available
          return caches.match('./index.html');
        })
    );
    return;
  }

  // Default: cache-first strategy
  event.respondWith(cacheFirstStrategy(request));
});

// ==================== CACHING STRATEGIES ====================

// Cache-first: Try cache, fallback to network
function cacheFirstStrategy(request) {
  return caches.match(request)
    .then((response) => {
      if (response) {
        return response;
      }
      
      return fetch(request).then((response) => {
        if (!response || response.status !== 200 || response.type !== 'basic') {
          return response;
        }
        
        const responseToCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(request, responseToCache);
        });
        
        return response;
      });
    })
    .catch((error) => {
      console.error('[ServiceWorker] Fetch failed:', error);
      throw error;
    });
}

// Network-first: Try network, fallback to cache
function networkFirstStrategy(request) {
  return fetch(request)
    .then((response) => {
      const responseToCache = response.clone();
      caches.open(DATA_CACHE_NAME).then((cache) => {
        cache.put(request, responseToCache);
      });
      return response;
    })
    .catch(() => {
      return caches.match(request);
    });
}

// ==================== BACKGROUND SYNC ====================
self.addEventListener('sync', (event) => {
  console.log('[ServiceWorker] Background sync event:', event.tag);
  
  if (event.tag === 'sync-sleep-logs') {
    event.waitUntil(syncSleepLogs());
  } else if (event.tag === 'sync-profile') {
    event.waitUntil(syncProfile());
  }
});

async function syncSleepLogs() {
  console.log('[ServiceWorker] Syncing sleep logs...');
  
  try {
    // In a full implementation with backend:
    // 1. Get pending logs from IndexedDB
    // 2. POST to backend API
    // 3. Clear pending logs on success
    
    // For now, just log
    console.log('[ServiceWorker] Sleep logs sync completed');
    return Promise.resolve();
  } catch (error) {
    console.error('[ServiceWorker] Sleep logs sync failed:', error);
    throw error;
  }
}

async function syncProfile() {
  console.log('[ServiceWorker] Syncing profile...');
  
  try {
    // Similar to syncSleepLogs but for profile data
    console.log('[ServiceWorker] Profile sync completed');
    return Promise.resolve();
  } catch (error) {
    console.error('[ServiceWorker] Profile sync failed:', error);
    throw error;
  }
}

// ==================== PUSH NOTIFICATIONS ====================
self.addEventListener('push', (event) => {
  console.log('[ServiceWorker] Push notification received');
  
  let data = {
    title: 'Sleep Optimizer',
    body: 'Zeit für deine Schlafvorbereitung!',
    icon: 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Ctext y=\'0.9em\' font-size=\'90\'%3E💤%3C/text%3E%3C/svg%3E',
    badge: 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 96 96\'%3E%3Ccircle cx=\'48\' cy=\'48\' r=\'48\' fill=\'%23667eea\'/%3E%3Ctext x=\'48\' y=\'68\' font-size=\'50\' text-anchor=\'middle\' fill=\'white\'%3E💤%3C/text%3E%3C/svg%3E',
    vibrate: [200, 100, 200],
    tag: 'sleep-reminder',
    requireInteraction: false,
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1,
      url: './'
    }
  };
  
  if (event.data) {
    try {
      const payload = event.data.json();
      data = { ...data, ...payload };
    } catch (e) {
      data.body = event.data.text();
    }
  }
  
  const options = {
    body: data.body,
    icon: data.icon,
    badge: data.badge,
    vibrate: data.vibrate,
    tag: data.tag,
    requireInteraction: data.requireInteraction,
    data: data.data,
    actions: [
      {
        action: 'open',
        title: 'App öffnen'
      },
      {
        action: 'dismiss',
        title: 'Verwerfen'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  console.log('[ServiceWorker] Notification clicked:', event.action);
  
  event.notification.close();
  
  if (event.action === 'dismiss') {
    return;
  }
  
  // Open or focus the app
  event.waitUntil(
    clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    })
    .then((clientList) => {
      // If app is already open, focus it
      for (let client of clientList) {
        if (client.url.includes(self.registration.scope) && 'focus' in client) {
          return client.focus();
        }
      }
      
      // Otherwise open new window
      if (clients.openWindow) {
        const urlToOpen = event.notification.data && event.notification.data.url 
          ? event.notification.data.url 
          : './';
        return clients.openWindow(urlToOpen);
      }
    })
  );
});

// Handle notification close
self.addEventListener('notificationclose', (event) => {
  console.log('[ServiceWorker] Notification closed');
});

// ==================== PERIODIC BACKGROUND SYNC ====================
// Note: Requires user permission and HTTPS
self.addEventListener('periodicsync', (event) => {
  console.log('[ServiceWorker] Periodic sync event:', event.tag);
  
  if (event.tag === 'update-reminders') {
    event.waitUntil(updateReminders());
  }
});

async function updateReminders() {
  console.log('[ServiceWorker] Updating reminders...');
  
  try {
    // Calculate next reminder times based on user's profile
    // Send scheduled notifications
    
    console.log('[ServiceWorker] Reminders updated');
    return Promise.resolve();
  } catch (error) {
    console.error('[ServiceWorker] Reminder update failed:', error);
    throw error;
  }
}

// ==================== MESSAGE HANDLING ====================
self.addEventListener('message', (event) => {
  console.log('[ServiceWorker] Message received:', event.data);
  
  if (event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => caches.delete(cacheName))
        );
      })
    );
  }
  
  if (event.data.type === 'CACHE_URLS') {
    event.waitUntil(
      caches.open(CACHE_NAME).then((cache) => {
        return cache.addAll(event.data.urls);
      })
    );
  }
  
  // Schedule notification
  if (event.data.type === 'SCHEDULE_NOTIFICATION') {
    scheduleNotification(event.data.payload);
  }
});

// ==================== NOTIFICATION SCHEDULING ====================
const scheduledNotifications = new Map();

function scheduleNotification(payload) {
  const { id, title, body, time, tag } = payload;
  
  // Clear existing timeout if any
  if (scheduledNotifications.has(id)) {
    clearTimeout(scheduledNotifications.get(id));
  }
  
  // Calculate delay
  const now = Date.now();
  const targetTime = new Date(time).getTime();
  const delay = targetTime - now;
  
  if (delay <= 0) {
    // Time already passed, show immediately
    showNotification(title, body, tag);
    return;
  }
  
  // Schedule for future
  const timeoutId = setTimeout(() => {
    showNotification(title, body, tag);
    scheduledNotifications.delete(id);
  }, delay);
  
  scheduledNotifications.set(id, timeoutId);
  
  console.log(`[ServiceWorker] Notification scheduled for ${new Date(time).toLocaleString()}`);
}

function showNotification(title, body, tag) {
  const options = {
    body: body,
    icon: 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Ctext y=\'0.9em\' font-size=\'90\'%3E💤%3C/text%3E%3C/svg%3E',
    badge: 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 96 96\'%3E%3Ccircle cx=\'48\' cy=\'48\' r=\'48\' fill=\'%23667eea\'/%3E%3Ctext x=\'48\' y=\'68\' font-size=\'50\' text-anchor=\'middle\' fill=\'white\'%3E💤%3C/text%3E%3C/svg%3E',
    vibrate: [200, 100, 200],
    tag: tag || 'sleep-reminder',
    requireInteraction: false
  };
  
  self.registration.showNotification(title, options);
}

// ==================== ERROR HANDLING ====================
self.addEventListener('error', (event) => {
  console.error('[ServiceWorker] Error:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('[ServiceWorker] Unhandled promise rejection:', event.reason);
});

// ==================== UTILITY FUNCTIONS ====================

// Cache size management
async function limitCacheSize(cacheName, maxItems) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  
  if (keys.length > maxItems) {
    // Delete oldest items
    const itemsToDelete = keys.slice(0, keys.length - maxItems);
    await Promise.all(itemsToDelete.map(key => cache.delete(key)));
    console.log(`[ServiceWorker] Cleaned up ${itemsToDelete.length} old cache items`);
  }
}

// Periodic cache cleanup (called during idle time)
self.addEventListener('idle', () => {
  limitCacheSize(DATA_CACHE_NAME, 50);
});

// ==================== INSTALLATION PROMPT ====================
// Note: This runs in the page context, not the service worker
// Included here for documentation

/*
// In your main app:

let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  // Show install button
});

async function installApp() {
  if (!deferredPrompt) return;
  
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  
  if (outcome === 'accepted') {
    console.log('User accepted the install prompt');
  }
  
  deferredPrompt = null;
}

// Detect if app is installed
window.addEventListener('appinstalled', () => {
  console.log('App was installed');
});

// Detect if running as PWA
if (window.matchMedia('(display-mode: standalone)').matches) {
  console.log('Running as installed PWA');
}
*/

console.log('[ServiceWorker] Service Worker loaded and ready');

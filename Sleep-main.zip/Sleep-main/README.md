# 💤 Sleep Optimizer

**Systematische Schlafoptimierung durch klare Regeln, nicht durch Motivation.**

Eine Progressive Web App (PWA) für iOS, Android und Desktop, die dir hilft, deinen Schlaf durch evidenzbasierte Zeitfenster und Gewohnheiten zu verbessern.

-----

## 🎯 Hauptziele

- **Schlafschuld reduzieren** über 14-Tage-Zeitraum
- **Zirkadiane Stabilität** maximieren
- **Langfristige Einhaltung** statt kurzfristige Motivation
- **Messbare Ergebnisse** innerhalb von 4 Wochen

-----

## ✨ Features

### Kernfunktionen

- ✅ **Schlafschuld-Tracking** mit Rolling-14-Day-Fenster
- ✅ **Automatische Cutoff-Berechnung** für Koffein, Mahlzeiten, Bildschirm, Schlafenszeit
- ✅ **Morgen-Protokoll** mit Schlafqualitäts-Bewertung
- ✅ **Wöchentliches Review** mit datenbasierten Empfehlungen
- ✅ **Anpassbare Regeln** basierend auf persönlichen Constraints
- ✅ **Offline-Funktionalität** - keine Internetverbindung nötig
- ✅ **Installierbar** als native App auf allen Plattformen

### System-Design

- 🎯 **Regel-basiert, nicht motivationsabhängig**
- 📊 **Datengesteuerte Anpassungen** jede Woche
- ⚡ **Automatische Durchsetzung** durch Zeitfenster
- 🔄 **Adaptive Regeln** passen sich deinem Verhalten an
- 🚫 **Keine Wearables erforderlich**
- 🔒 **100% lokale Datenspeicherung**

-----

## 📱 Installation

### Schnellstart

1. **Öffne die App** in deinem Browser
1. **Klicke auf “Installieren”** (wenn der Button erscheint)
1. **Fertig!** Die App ist jetzt auf deinem Gerät installiert

Detaillierte Anleitung: <INSTALLATION.md>

-----

## 🚀 Verwendung

### Erster Start: Onboarding (5 Minuten)

1. **Aufwachzeit festlegen** (z.B. 7:00 Uhr an Werktagen)
1. **Früheste Schlafenszeit** basierend auf Constraints (Arbeit, Familie)
1. **Schlafbedarf einstellen** (Standard: 7.5 Stunden)
1. **Zeitfenster konfigurieren** (Koffein, Mahlzeiten, Bildschirm)

### Tägliche Routine

**Morgens:**

- Aufwachzeit protokollieren
- Schlafqualität bewerten (1-5)
- Nächtliches Aufwachen notieren

**Tagsüber:**

- Koffein-Intake loggen (mit Zeitstempel)
- Mahlzeiten protokollieren
- Training erfassen (Dauer & Intensität)

**Abends:**

- Deadlines beachten (App erinnert dich)
- Cutoff-Zeiten einhalten
- Vor Schlafenszeit zur Ruhe kommen

**Wöchentlich (Sonntag Abend):**

- Review durchführen
- Empfehlungen prüfen
- Regeln anpassen (falls nötig)

-----

## 📊 Wie es funktioniert

### Schlafschuld-Kalkulation

```
Schlafschuld = Σ (Tatsächlicher Schlaf - Schlafbedarf) über 14 Tage

Beispiel:
- Schlafbedarf: 7.5h pro Nacht
- Tatsächlicher Schlaf: 6.5h
- Delta: -1h
- Nach 7 Tagen: -7h Schlafschuld
```

### Cutoff-Zeiten Berechnung

```
Schlafenszeit = Aufwachzeit - (Schlafbedarf + Schuldfaktor)
Schuldfaktor = min(Schlafschuld / 7, 1.0h)

Koffein-Cutoff = Schlafenszeit - 10h (konservativ)
Mahlzeit-Cutoff = Schlafenszeit - 3h
Bildschirm-Cutoff = Schlafenszeit - 1.5h
```

### Wöchentliche Anpassungen

**Bei Verschlechterung der Schlafschuld:**

- Identifiziere häufigste Regelverstöße
- Passe verletzten Cutoff an (z.B. Koffein 1h früher)
- Verschärfe Durchsetzung bei Bedarf

**Bei Verbesserung:**

- Teste ob weniger Schlaf ausreicht (-15min)
- Oder: Halte erfolgreiches System bei

-----

## 🎓 Wissenschaftliche Grundlagen

### Koffein-Halbwertszeit

- **5.5 Stunden** durchschnittliche Halbwertszeit
- **10 Stunden vor Schlaf:** Konservativer Cutoff
- **Schwelle:** <25mg aktives Koffein zur Schlafenszeit

### Mahlzeiten & Schlaf

- **3 Stunden Verdauungszeit** vor Schlaf
- **Kohlenhydrat-Timing:** 4-6h vor Schlaf (Serotonin→Melatonin)
- **Protein >40g:** Zusätzliche +30min Vorlaufzeit

### Bewegung & Erholung

- **High-Intensity:** 5h Abstand zum Schlaf
- **Krafttraining:** 4h Abstand
- **Cardio (Zone 2):** 2h Abstand
- **Trade-off:** Bei Schlafschuld >3h → Ruhe priorisieren

### Bildschirm & Licht

- **90min vor Schlaf:** Reduzierte Exposition
- **Blaues Licht:** Melatonin-Suppression
- **Kognitive Erregung:** Social Media > Passive Videos > Lesen

-----

## 📈 Metriken & Erfolg

### Primäre Metriken (wichtig)

1. **Schlafschuld-Trend** (14-Tage-Durchschnitt)
- Ziel: Konvergenz zu 0 ± 1h
1. **Zirkadiane Stabilität** (Varianz der Mittelschlafzeit)
- Ziel: <45min Standardabweichung
1. **Regeleinhaltung** (% der Cutoffs eingehalten)
- Ziel: >80% nach 4 Wochen
1. **Nächster-Tag-Performance** (optional, selbstbewertet)
- Ziel: Korrelation >0.5 mit Schlafschuld

### Irreführende Metriken (ignorieren)

- ❌ Gesamtschlafzeit (allein)
- ❌ Schlaf-Score von Wearables
- ❌ REM/Tiefschlaf-Prozentsätze
- ❌ Ruheherzfrequenz (zu viele Faktoren)

### Verbesserung vs. Placebo

Nach 4 Wochen:

|Schlafschuld         |Einhaltung >80%|Einhaltung <60% |
|---------------------|---------------|----------------|
|**Verbessernd**      |✅ Erfolg       |⚠️ Extern/Placebo|
|**Stabil/Schlechter**|⚠️ Erhalt/Zeit  |❌ Fehler        |

-----

## 🔧 Architektur

### Tech Stack

```
Frontend: React 18 (CDN)
Styling: Pure CSS
State: React Hooks + LocalStorage
PWA: Service Worker + Manifest
Charts: Chart.js 4
Build: None (keine Dependencies!)
```

### Dateistruktur

```
sleep-optimizer/
├── index.html           # Haupt-App (Single File)
├── manifest.json        # PWA Manifest
├── service-worker.js    # Offline-Funktionalität
├── INSTALLATION.md      # Installations-Anleitung
└── README.md           # Diese Datei
```

### Keine Build-Tools

- ✅ Kein npm/yarn
- ✅ Kein Webpack/Vite/Rollup
- ✅ Kein Transpiling
- ✅ Einfach öffnen und nutzen

-----

## 🔒 Datenschutz

### Was wird gespeichert?

- **Profil:** Aufwachzeit, Schlafbedarf, Cutoffs
- **Logs:** Schlafqualität, Koffein, Mahlzeiten, Training
- **Berechnungen:** Schlafschuld, Adherence-Rate

### Wo wird gespeichert?

- **100% lokal** auf deinem Gerät
- **LocalStorage** im Browser
- **Kein Cloud-Upload**
- **Keine Analytics**
- **Kein Tracking**

### Wie lösche ich Daten?

- **In der App:** Einstellungen → “Alle Daten zurücksetzen”
- **Im Browser:** Cookies/Daten löschen

-----

## 🛠️ Entwicklung

### Lokal testen

```bash
# Python
python -m http.server 8000

# Node.js
npx http-server -p 8000

# PHP
php -S localhost:8000
```

Dann öffne: `http://localhost:8000`

### Anpassen

Die komplette App ist in `index.html`. Ändere:

- **Styles:** `<style>` Block
- **Logik:** `<script type="text/babel">` Block
- **Cutoffs:** Standardwerte in `profile` State
- **Texte:** Direkt in den Komponenten

### Deployment

**GitHub Pages:**

```bash
git add .
git commit -m "Deploy"
git push origin main
# Aktiviere Pages in Repo Settings
```

**Netlify:**

- Drag & Drop des Ordners auf netlify.com

**Vercel:**

- Import GitHub Repo oder Upload Ordner

-----

## 📋 Roadmap

### Version 1.0 (Aktuell - MVP)

- ✅ Onboarding
- ✅ Tägliches Logging
- ✅ Schlafschuld-Tracking
- ✅ Cutoff-Berechnung
- ✅ Wöchentliches Review
- ✅ PWA-Installation
- ✅ Offline-Modus

### Version 1.1 (Geplant)

- 🔲 Push-Benachrichtigungen
- 🔲 Export/Import (JSON)
- 🔲 Erweiterte Charts
- 🔲 Dunkelmodus
- 🔲 Mehrsprachigkeit (EN/DE)

### Version 2.0 (Zukunft)

- 🔲 Cloud-Sync (optional)
- 🔲 Wearable-Integration
- 🔲 Statistik-Dashboard
- 🔲 Korrelations-Analysen
- 🔲 Erweiterte Empfehlungen

-----

## 🤝 Beitragen

Contributions willkommen!

1. Fork das Projekt
1. Erstelle einen Feature Branch (`git checkout -b feature/AmazingFeature`)
1. Commit deine Änderungen (`git commit -m 'Add some AmazingFeature'`)
1. Push zum Branch (`git push origin feature/AmazingFeature`)
1. Öffne einen Pull Request

### Code-Style

- Klare, beschreibende Variablennamen
- Kommentare für komplexe Logik
- Funktionale Komponenten (React Hooks)
- Pure CSS (kein Tailwind/Bootstrap)

-----

## 📄 Lizenz

MIT License - Siehe <LICENSE> Datei

**TL;DR:** Nutze, modifiziere, verteile frei. Keine Garantien.

-----

## 🙏 Credits

### Inspiration

- Matthew Walker - “Why We Sleep”
- Andrew Huberman - Schlaf-Optimierungs-Protokolle
- CBT-I (Cognitive Behavioral Therapy for Insomnia)

### Tech

- React Team
- Chart.js Contributors
- PWA Community

-----

## 📞 Support

- **Bugs:** Öffne ein GitHub Issue
- **Fragen:** Siehe <INSTALLATION.md>
- **Features:** Pull Request oder Issue

-----

## ⚠️ Disclaimer

Diese App ist **kein medizinisches Gerät** und ersetzt keine professionelle Beratung.

**Bei anhaltenden Schlafproblemen:**

- Konsultiere einen Arzt
- Schlafapnoe-Screening erwägen
- Psychotherapie bei Insomnie (CBT-I)

**Die App hilft bei:**

- Verhaltensoptimierung
- Gewohnheitsbildung
- Systematischem Tracking

**Die App hilft NICHT bei:**

- Medizinischen Schlafstörungen
- Schlafapnoe
- Narkolepsie
- Schweren Insomnien

-----

## 📚 Weiterführende Ressourcen

### Bücher

- “Why We Sleep” - Matthew Walker
- “The Sleep Solution” - Chris Winter
- “Say Good Night to Insomnia” - Gregg Jacobs

### Podcasts

- Huberman Lab (Schlaf-Episoden)
- The Matt Walker Podcast
- Found My Fitness (Rhonda Patrick)

### Wissenschaft

- [Sleep Research Society](https://www.sleepresearchsociety.org/)
- [National Sleep Foundation](https://www.thensf.org/)
- [PubMed - Sleep Studies](https://pubmed.ncbi.nlm.nih.gov/?term=sleep)

-----

**Optimiere deinen Schlaf. Systematisch. 💤**

-----

## Version

**Aktuelle Version:** 1.0.0  
**Letztes Update:** Februar 2026  
**Status:** Stable MVP
